package com.company.yearsanddayscalculator;

public class MinutesToYearsDaysCalculator {
    public static void printYearsAndDays(long minutes) {
        if (minutes < 0) {
            System.out.println("Invalid value");
        } else {
            long years = minutes / 60 / 24 / 365;
            long days = (minutes / 60 / 24) % 365;
            String yearsstring = years + "y ";
            String daysstring = days + "d ";
            String minutesstring = minutes + "min ";
            if (years < 10) {
                yearsstring = "0" + yearsstring;
            }
            if (days < 10) {
                daysstring = "0" + daysstring;
            }
            if (minutes < 10) {
                minutesstring = "0 " + minutesstring;
            }
            System.out.println(minutesstring + "= " + yearsstring + "and " + daysstring);
        }
    }

    public static void main(String[] args) {
        printYearsAndDays(-525600);
    }
}
