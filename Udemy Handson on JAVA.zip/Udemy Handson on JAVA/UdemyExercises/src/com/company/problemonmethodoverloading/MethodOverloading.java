package com.company.problemonmethodoverloading;

import java.util.Scanner;

public class MethodOverloading {
    public static double calcFeetAndInchesToCentimetres(double feet, double inches){
        if((feet<0)||((inches<0)||(inches>12))) {
            //System.out.println("Invalid parametres");
            return -1;
        }
            return ((feet*12*2.54) + (inches*2.54));
    }

    public static double calcFeetAndInchesToCentimetres(double inches){
        if (inches<0){
            return -1;
        }
        double feet1 = (int)  (inches/12);
        double inchesremaining = inches%12;
        return calcFeetAndInchesToCentimetres(feet1,inchesremaining);

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter  feet and inches");
        double f = sc.nextDouble();
        double i = sc.nextDouble();
        double d1=calcFeetAndInchesToCentimetres(f,i);
        if (d1==-1){
            System.out.println("Invalid parametres");
        }
        else{
        System.out.println("The converted centimetres for " + f + "feet and " + i + " inches is = " + d1);

//        System.out.println("Enter inches");
//        double f2 = sc.nextDouble();
       double d2 =  calcFeetAndInchesToCentimetres(i);
        System.out.println("the converted centimetres for " + i + "inches is = "+ d2);
        }
    }
}
