package com.company;

import java.util.Scanner;

public class SecondsAndMinuteChallenge {
    public static String getDurationString(long minutes, long seconds){
        if((minutes<0)||((seconds<0)||(seconds>59))){
            return "Invalid Value";
        }
        long hrs = minutes/60;
        long mins = minutes%60;
        String hoursstring = hrs+"h ";
        String minsstring = mins+"m ";
        String secondsstring = seconds+"s ";
        if(hrs<10){
            hoursstring="0"+hoursstring;
        }
        if (mins<10){
            minsstring="0"+minsstring;
        }
        if(seconds<10){
            secondsstring="0"+secondsstring;
        }
        return hoursstring + minsstring + secondsstring;
    }
    public static String getDurationString(long seconds){
        if (seconds<0){
            return "Invalid Value";
        }
        long mins1 = seconds/60;
        long sec1 = seconds%60;
        return getDurationString(mins1,sec1);
    }
    public static void main(String[] args) {
        System.out.println("Enter minutes and seconds");
        Scanner sc=new Scanner(System.in);
        long a = sc.nextLong();
        long b = sc.nextLong();
        System.out.println(getDurationString(a,b));
        System.out.println("Enter seconds");
        long c= sc.nextLong();
        System.out.println(getDurationString(c));
    }
}
