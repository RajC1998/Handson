package academy.learnprograming;

import java.util.Scanner;

public class Methods {
    public static void main(String[] args) {

    }


}


