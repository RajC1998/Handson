package academy.learnprograming;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("1 to check any number . 2 to exit");
            int confirm = sc.nextInt();
            switch (confirm) {
                case 1: {

                    System.out.println("Enter a number to check ");
                    double number = sc.nextDouble();
                    checkNumber(number);
                }
                break; }
            case 2:
                System.out.println("Come back soon");
                break;
            default:
                System.out.println("Enter valid number");
        }
    }

    public static void checkNumber(double number){
        if (number>0)
            System.out.println("Positive");
        else if(number<0)
            System.out.println("Negative");
        else
            System.out.println("number is zero");
    }
}
