package academy.learnprograming;

public class Gaming {
    public static int calculateHighScorePosition(int score){
        int position;
        if(score>=1000){
            position = 1;
        }
        else if (score>=500){
            position =2;
        }
        else if(score>=100){
            position=3;
        } else
        position=4;
        return position;
    }

    public static void displayHighScorePosition(String name, int position){
        System.out.println(name + " managed to get the position " + position + " on the high score table");
    }

    public static void main(String[] args) {


       // int playerPosition = calculateHighScorePosition(1500);
        displayHighScorePosition("Rahul ", calculateHighScorePosition(1500));
      //  int rajPosition = calculateHighScorePosition(900);
        displayHighScorePosition("Raj", calculateHighScorePosition(900));
      //  int rohanPosition = calculateHighScorePosition(400);
        displayHighScorePosition("Rohan", calculateHighScorePosition(400));
      //  int rajeevPosition = calculateHighScorePosition(50);
        displayHighScorePosition("Rajeev" ,calculateHighScorePosition(50));

    }


}
