package com.udemy;

public class Main {
    public static void main(String[] args) {



       int score = 10000;
       int levelCompleted = 8;
       int bonus = 200;
       boolean isGameOver= true;
       if (isGameOver){
           int finalScore = score + (levelCompleted*bonus);
           System.out.println("Final score is " + finalScore);
       }
    }

}