package com.company;

public class SharedDigit {
    public static boolean hasSharedDigit(int number1, int number2){
        if ((number1<10)||(number2<10)){
            return false;
        }
        int num1LD = number1%10;
        int num1FD = number1/10;
        int num2LD = number2%10;
        int num2FD = number2/10;
        return ((num1FD==num2FD)||(num1FD==num2LD)||(num1LD==num2FD)||(num1LD==num2LD));
    }

    public static void main(String[] args) {
        System.out.println(hasSharedDigit(15,55));
    }
}
