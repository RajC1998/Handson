package com.company;

public class PrimeNumber {
    public static void main(String[] args) {
     int count = 0;
     for (int n=1;n<101;n++){
         if (isPrime(n)){
             count++;
             System.out.println(" "+n);
//             if (count==3){
//                 break;
//             }
         }


     }
//        System.out.println(count);

    }
    public static boolean isPrime(int num){
        if (num==1){
            return false;
        }
        for (int i = 2; i<=(long)Math.sqrt(num);i++){
            System.out.println("Looping "+i);
            if (num%i==0){
                return false;
            }
        }
        return true;
    }
}

