package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a character");
	  char alpha = sc.next().charAt(0);
	switch (alpha){
        case 'A':
            System.out.println("it was A");
            break;
        case 'B':
            System.out.println("It was B");
            break;
        case 'C': case 'D': case 'E':
            System.out.println("it was "+alpha);
            break;
//        case 'D':
//            System.out.println("It was D");
//            break;
//        case 'E':
//            System.out.println("It was E");
//            break;
        default:
            System.out.println("None of A,B,C,D or E");
	}

    }
}
