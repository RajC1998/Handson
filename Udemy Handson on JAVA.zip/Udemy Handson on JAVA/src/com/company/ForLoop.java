package com.company;

public class ForLoop {
    public static void calculateInterest(long amount, double interest){
        for(double i= interest ;i>=2;i-=.5){
            System.out.println(amount+" at "+ i+"% "+ "interest = "+(amount*(i/100)));
        }
    }

    public static void main(String[] args) {
        calculateInterest(10000,8);
    }
}
