package com.company;

public class Testing {
    public static void main(String[] args) {
        int noOfZeroes=2;
        for (int i = 1; i <= noOfZeroes; i++) {
            System.out.print("Zero ");
        }
    }
}
