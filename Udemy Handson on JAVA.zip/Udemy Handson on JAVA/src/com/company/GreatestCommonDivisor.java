package com.company;

public class GreatestCommonDivisor {
    public static int getGreatestCommonDivisor(int num1, int num2) {
        if (num1 < 10 || num2 < 10) {
            return -1;
        }
        if (num1 == num2) {
            return num1;
        }
        int a = num1;
        int b = num2;
        int hcf = 0;
        if (a > b) {
            for (int i = b; i >= 1; i--) {
                if ((num1 % i == 0) && (num2 % i == 0)) {
                    hcf = i;
                    break;

                }

            }
            return hcf;
        } else {
            for (int i = a; i >= 1; i--) {
                if ((num1 % i == 0) && (num2 % i == 0)) {
                    hcf = i;
                    break;
                }
            }
            return hcf;
        }
    }

    public static void main(String[] args) {
        System.out.println("HCF is " + getGreatestCommonDivisor(12,27));
    }
}