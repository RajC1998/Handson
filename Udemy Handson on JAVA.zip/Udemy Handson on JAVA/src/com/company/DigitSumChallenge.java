package com.company;

import java.util.Scanner;

public class DigitSumChallenge {
    public static int sumDigit(int number){
        if(number<10){
            System.out.println("Invalid input");
            return -1;
        }
        int unitDigit = 0;
        while(number!=0){
            unitDigit += number%10;
            number/= 10;

        }
        return unitDigit;
    }

    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter a number to find digit sum");
        int a = sc.nextInt();
        System.out.println("the digit sum is "+ sumDigit(a));
    }
}
