package com.company;

public class FirstLastDigitSum {
    public static int sumFirstAndLastDigit(int number){
        if (number<0){
            return -1;
        }
        if(number==0){
            return 0;
        }
        int lastDigit=0;
        int firstDigit = 0;
        lastDigit=number%10;
        while (number!=0){

            if ((number<10)&&(number>0)){
                firstDigit=number;
            }
            number/=10;
        }

        return lastDigit+firstDigit;
    }

    public static void main(String[] args) {
        System.out.println("THe sum is = " + sumFirstAndLastDigit(8757));
    }
}
