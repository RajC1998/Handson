package com.company;

public class NumberPalindrome {
    public static boolean isPalindrome(int num){
        int actualNum=num;
        int unitDigit=0;
        int reverseNum=0;
        while (num!=0){
            unitDigit = (num%10);
            num/=10;
            reverseNum = (reverseNum*10) + unitDigit;
        }
        return reverseNum == actualNum;
    }

    public static void main(String[] args) {
        System.out.println(isPalindrome(-858));
    }
}
