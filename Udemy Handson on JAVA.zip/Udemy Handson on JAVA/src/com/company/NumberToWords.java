package com.company;

public class NumberToWords {
    public static void numberToWords(int number){
        if (number<0){
            System.out.println("Invalid Value");
        }
        else {


            int noOfDigitsON = getDigitCount(number);
            int reversedNumber = reverse(number);
            int noOfDigitsRN = getDigitCount(reversedNumber);
            int noOfZeroes = noOfDigitsON - noOfDigitsRN;
            for (int i = 1; i <= noOfZeroes; i++) {
                System.out.print("Zero ");
            }
            int unitDigit=0;
            while (reversedNumber >= 0) {
                unitDigit = reversedNumber % 10;
                if (unitDigit == 0)
                    System.out.print("Zero ");
                else if (unitDigit == 1)
                    System.out.print("One ");
                else if (unitDigit == 2)
                    System.out.print("Two ");
                else if (unitDigit == 3)
                    System.out.print("Three ");
                else if (unitDigit == 4)
                    System.out.print("Four ");
                else if (unitDigit == 5)
                    System.out.print("Five ");
                else if (unitDigit == 6)
                    System.out.print("Six ");
                else if (unitDigit == 7)
                    System.out.print("Seven ");
                else if (unitDigit == 8)
                    System.out.print("Eight ");
                else System.out.print("Nine ");
                reversedNumber /= 10;
            }
        }
    }
    public static int reverse(int number){
        int revNum = 0;
        while (number!=0){
            revNum = (10*revNum + (number%10));
            number/=10;
        }
        return revNum;
    }
    public static int getDigitCount(int number){
        int count = 0;
        if (number<0){
            return -1;
        }
        do {
            count++;
            number/=10;
        }
        while (number!=0);
        return count;
    }

    public static void main(String[] args) {
//        System.out.println(reverse(6));
        //System.out.println(getDigitCount(8));
        numberToWords(100);
    }
}
