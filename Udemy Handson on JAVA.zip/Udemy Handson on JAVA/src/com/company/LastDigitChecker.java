package com.company;

public class LastDigitChecker {
    public static boolean haSameLastDigit(int num1, int num2, int num3) {
        if ((num1 < 10 || num2 < 10 || num3 < 10) || (num1 > 1000 || num2 > 1000 || num3 > 1000)) {
            System.out.println("invalid input");
            return false;
        }
        int a = num1 % 10;
        int b = num2 % 10;
        int c = num3 % 10;
        return ((a == b) || (b == c) || (c == a));
    }


    public static boolean isValid(int number){
        return (number>10&&number<1000);
    }
    public static void main(String[] args) {
        System.out.println(haSameLastDigit(23,33,56));
        System.out.println(isValid(1));
    }
}
