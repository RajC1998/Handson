package com.company;

public class Sum3And5Challenge {
    public static void main(String[] args) {
        int sum=0;
        int count=0;
        for (int num=1;num<=1000;num++){
            if ((num%3==0)&&(num%5==0)){
                count++;
                              System.out.println("Number is = "+num);
                sum = sum+num;
            }
//            if(count==5){
//                break;
//            }
        }
        System.out.println("the sum of all the  numbers is = " +sum);
    }
}
